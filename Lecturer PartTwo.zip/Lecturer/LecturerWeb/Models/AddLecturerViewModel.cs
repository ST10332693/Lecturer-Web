﻿using LecturerWeb.Models.Entities;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LecturerWeb.Models
{
    public class AddLecturerViewModel
    {
        public int LecturerId { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        public required string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        public required string LastName { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
        public required string Email { get; set; }

        [Phone(ErrorMessage = "Invalid phone number format.")]
        public required string PhoneNumber { get; set; }

        public required string Department { get; set; }
        public required string Role { get; set; }

        [Required(ErrorMessage = "Bank account number is required.")]
        public required string BankAccountNumber { get; set; }

        public required string BankName { get; set; }
        public required string EmployeeNumber { get; set; }

        public ICollection<Claim> Claims { get; set; } = new List<Claim>();
    }
}
