﻿namespace LecturerWeb.Models.Entities { 
public class ClaimViewModel
{
    public int ClaimId { get; set; }
    public required string Description { get; set; }
    public DateTime DateSubmitted { get; set; }
    public int LecturerId { get; set; }
    // Add other properties as needed
}
}