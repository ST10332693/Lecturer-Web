﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LecturerWeb.Models.Entities
{
    public class Claim
    {
        [Key]
        public int ClaimId { get; set; }

        [ForeignKey("Lecturer")]
        public int LecturerId { get; set; }

        [Required]
        [Range(0, 1000, ErrorMessage = "Hours worked must be between 0 and 1000.")]
        public double HoursWorked { get; set; }

        [Required]
        [Range(0, 10000, ErrorMessage = "Hourly rate must be between 0 and 10000.")]
        public decimal HourlyRate { get; set; }

        public string? AdditionalNotes { get; set; }

        [Required]
        public DateTime SubmissionDate { get; set; } = DateTime.Now;

        [Required]
        [EnumDataType(typeof(ClaimStatus))]
        public ClaimStatus Status { get; set; }

        // Navigation property to link to the Lecturer
        public Lecturer? Lecturer { get; set; }
    }
}

