﻿using LecturerWeb.Data;
using LecturerWeb.Models;
using LecturerWeb.Models.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace LecturerWeb.Controllers
{
    public class LecturerController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public LecturerController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddLecturerViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }

            var lecturer = new Lecturer
            {
                FirstName = viewModel.FirstName,
                LastName = viewModel.LastName,
                Email = viewModel.Email,
                PhoneNumber = viewModel.PhoneNumber,
                Department = viewModel.Department,
                Role = viewModel.Role,
                BankAccountNumber = viewModel.BankAccountNumber,
                BankName = viewModel.BankName,
                EmployeeNumber = viewModel.EmployeeNumber
            };

            await dbContext.Lecturers.AddAsync(lecturer);
            await dbContext.SaveChangesAsync();
            return RedirectToAction("List");
        }

        [HttpGet]
        public async Task<IActionResult> List()
        {
            var lecturers = await dbContext.Lecturers.ToListAsync();
            return View(lecturers);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int lecturerId)
        {
            var lecturer = await dbContext.Lecturers.FindAsync(lecturerId);
            if (lecturer == null)
            {
                return NotFound(); // Return 404 if not found
            }
            return View(lecturer);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Lecturer viewModel)
        {
            var lecturer = await dbContext.Lecturers.FindAsync(viewModel.LecturerId);
            if (lecturer == null)
            {
                return NotFound(); // Return 404 if not found
            }

            // Update properties
            lecturer.FirstName = viewModel.FirstName;
            lecturer.LastName = viewModel.LastName;
            lecturer.Email = viewModel.Email;
            lecturer.PhoneNumber = viewModel.PhoneNumber;
            lecturer.Department = viewModel.Department;
            lecturer.Role = viewModel.Role;
            lecturer.BankAccountNumber = viewModel.BankAccountNumber;
            lecturer.BankName = viewModel.BankName;
            lecturer.EmployeeNumber = viewModel.EmployeeNumber;

            await dbContext.SaveChangesAsync();
            return RedirectToAction("List");
        }

        [HttpGet]
        public async Task<IActionResult> ClaimList(int lecturerId)
        {
            var claims = await GetClaimsByLecturerId(lecturerId);
            return View(claims);
        }

        [HttpGet]
        public IActionResult AddNewClaim(int lecturerId)
        {
            ViewData["LecturerId"] = lecturerId;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddNewClaim(int lecturerId, Claim claim)
        {
            claim.LecturerId = lecturerId;

            if (!ModelState.IsValid)
            {
                ViewData["LecturerId"] = lecturerId;
                return View("AddNewClaim", claim);
            }

            try
            {
                await dbContext.Claims.AddAsync(claim);
                await dbContext.SaveChangesAsync();
                TempData["SuccessMessage"] = "Claim added successfully!";
                return RedirectToAction("ClaimList", new { lecturerId });
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "An error occurred while adding the claim. Please try again.");
                return View("AddNewClaim", claim);
            }
        }

        private async Task<List<Claim>> GetClaimsByLecturerId(int lecturerId)
        {
            return await dbContext.Claims
                .Include(c => c.Lecturer)
                .Where(c => c.LecturerId == lecturerId)
                .ToListAsync();
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var lecturer = await dbContext.Lecturers.FindAsync(id);
            if (lecturer == null)
            {
                return NotFound();
            }
            return View(lecturer);
        }

        [HttpGet]
        public IActionResult AddManager()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddManager(Manager manager)
        {
            if (!ModelState.IsValid)
            {
                return View(manager);
            }

            try
            {
                await dbContext.Managers.AddAsync(manager);
                await dbContext.SaveChangesAsync();
                TempData["SuccessMessage"] = "Manager added successfully!";
                return RedirectToAction(nameof(ManagerList));
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "An error occurred while adding the manager. Please try again.");
                return View(manager);
            }
        }

        [HttpGet]
        public async Task<IActionResult> ManagerList()
        {
            var managers = await dbContext.Managers.ToListAsync();
            return View(managers);
        }
    }
}







