﻿namespace LecturerWeb.Models.Entities
{
    public class Manager
    {
        public int ManagerId { get; set; }
        public required string FirstName { get; set; }
        public required string LastName { get; set; }
        public required string Email { get; set; }

        // The list of claims they have reviewed
        public required List<ClaimReview> ClaimReview { get; set; }
    }

}
