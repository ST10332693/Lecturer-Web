﻿namespace LecturerWeb.Models.Entities
{
    public enum ClaimStatus
    {
        Pending,
        Approved,
        Rejected
    }
}