﻿using LecturerWeb.Models.Entities;
using System.ComponentModel.DataAnnotations;

namespace LecturerWeb.Models.Entities
{
    public class Lecturer
    {
        [Key]
        public int LecturerId { get; set; }

        [Required]
        [MaxLength(100)]
        public required string FirstName { get; set; }

        [Required]
        [MaxLength(100)]
        public required string LastName { get; set; }

        [EmailAddress]
        public string? Email { get; set; } // Nullable email

        [Phone]
        public string? PhoneNumber { get; set; } // Nullable phone number

        public string? Department { get; set; } // Nullable department

        public string Role { get; set; } // Nullable role

        public string? BankAccountNumber { get; set; } // Nullable account number

        public string? BankName { get; set; } // Nullable bank name

        public string? EmployeeNumber { get; set; } // Nullable employee number

        // Navigation property
        public ICollection<Claim>? Claims { get; set; }
    }
}