﻿using LecturerWeb.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace LecturerWeb.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Lecturer> Lecturers { get; set; }
        public DbSet<Claim> Claims { get; set; }
      
        public DbSet<ClaimReview> ClaimReviews { get; set; }
        public DbSet<Manager> Managers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuring the Lecturer entity
            modelBuilder.Entity<Lecturer>()
                .HasKey(l => l.LecturerId);

            modelBuilder.Entity<Claim>()
                .HasKey(c => c.ClaimId); // Ensure the primary key is defined

            modelBuilder.Entity<Claim>()
                .HasOne(c => c.Lecturer)
                .WithMany(l => l.Claims)
                .HasForeignKey(c => c.LecturerId)
                .OnDelete(DeleteBehavior.Cascade); // Optional: set delete behavior

            modelBuilder.Entity<ClaimReview>()
                .HasKey(cr => cr.ReviewId); // Configure primary key for ClaimReview

            modelBuilder.Entity<Lecturer>()
     .Property(l => l.Email)
     .IsRequired(); // Ensure this is required if it shouldn't be null


            modelBuilder.Entity<ClaimReview>()
                .HasOne(cr => cr.Managers)
                .WithMany(m => m.ClaimReview) // Assuming Manager has a navigation property for ClaimReviews
                .HasForeignKey(cr => cr.ManagerId)
                .OnDelete(DeleteBehavior.Restrict); 

            modelBuilder.Entity<Manager>()
                .HasKey(m => m.ManagerId); // Configure primary key for Manager

            base.OnModelCreating(modelBuilder);
        }
    }
}


