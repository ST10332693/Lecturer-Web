﻿namespace LecturerWeb.Models.Entities
{
    public class ClaimReview
    {
        public int ReviewId { get; set; }
        public int ClaimId { get; set; }
        public required Claim Claims { get; set; }

        public int ManagerId { get; set; }
        public required Manager Managers { get; set; }

        public ClaimStatus Status { get; set; }
        public DateTime ReviewDate { get; set; }
    }

}